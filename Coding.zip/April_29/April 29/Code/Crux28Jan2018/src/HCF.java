import java.util.Scanner;

/**
 * @author Garima Chhikara
 * @date Jan 28, 2018
 */

public class HCF {

	public static void main(String[] args) {

		Scanner scn = new Scanner(System.in);
		int n1 = scn.nextInt();
		int n2 = scn.nextInt();

	}

}

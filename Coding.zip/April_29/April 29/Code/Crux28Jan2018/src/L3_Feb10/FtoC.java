package L3_Feb10;

import java.util.Scanner;

/**
 * @author Garima Chhikara
 * @date 10-Feb-2018 
 */

public class FtoC {

	public static void main(String[] args) {
		
		Scanner scn= new Scanner(System.in) ;
		
		int minF = scn.nextInt() ;
		int maxF = scn.nextInt() ;
		int steps = scn.nextInt() ;
		
		for(int i = minF ; i <= maxF ; i = i + steps) {
			
			int c = (int) ((5.0/9) * (i - 32)) ;
		
			System.out.println(i + "\t" + c);
		}

	}

}

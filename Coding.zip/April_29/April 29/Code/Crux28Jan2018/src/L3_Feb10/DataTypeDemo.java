package L3_Feb10;

/**
 * @author Garima Chhikara
 * @date 10-Feb-2018
 */

public class DataTypeDemo {

	public static void main(String[] args) {

		byte by = 10;
		short sh = 10;
		int in = 10;
		long lo = 10;

		// Part 1
		// by = sh;
		// by = in;
		// by = lo;

		sh = by;
		// sh = in;
		// sh = lo;

		in = by;
		in = sh;
		// in = lo;

		lo = by;
		lo = sh;
		lo = in;

		// Part 2
		by = 10;
		by = (byte) 128;
		System.out.println(by);
		by = (byte) 259;
		System.out.println(by);

		// Part 3
		System.out.println(10000000000L);
		lo = 10000000000L;
		System.out.println(lo);
		// System.out.println(10000000000L);

		// Part 4
		float fll = 5.5f;
		float fl = (float) 5.5;
		double db = 5.5;

		// System.out.println(db);
		// fl = db;
		db = fl;

		// Part 5
		// in = fl;
		in = (int) fl;
		in = (int) db;
		System.out.println(in);
		fl = in;
		System.out.println(fl);

		// Part 6
		boolean bl = true;
		bl = false;
		// bl = 0;
		// bl = 1;

		// if (in) {
		// System.out.println("hi");
		// } else {
		// System.out.println("bye");
		// }

		if (in > 0) {
			System.out.println("hi");
		} else {
			System.out.println("bye");
		}

		if (bl) {
			System.out.println("hi");
		} else {
			System.out.println("bye");
		}

		// Part 7
		char ch;
		ch = 'a';
		// ch = 97;
		System.out.println(ch);

		in = ch;
		System.out.println((char) in);
		// ch = (char) in;

		in = ch + 2;
		System.out.println((char) in);
		// System.out.println((char) (ch + 2));
		// ch = (char) (ch + 2);

		// Part 8
		System.out.println(10 + 20 + "Hello" + 10 + 20);
		System.out.println(2 + ' ' + 5);
		System.out.println(2 + " " + 5);
		System.out.println("Hello" + '\t' + "World");
		System.out.println("Hello" + "\t" + "World");

		// System.out.println("\t");

	}

}

package L3_Feb10;

/**
 * @author Garima Chhikara
 * @date 10-Feb-2018
 */

public class FunctionDemo {

	public static int abc;

	public static void main(String[] args) {

		// Part-1
		System.out.println("----------- Part-1 -----------");
		addition();
		// int sub = subtraction();
		// System.out.println(s);

		// Part-2a
		System.out.println("----------- Part-2a -----------");
		System.out.println("hello");
		int sum1 = additionRV();
		System.out.println(sum1);
		System.out.println("bye");

		// Part-2b
		System.out.println("----------- Part-2b -----------");
		System.out.println("hello");
		additionWithParams(3, 4, 6, 7);
		
		// Part-3
		System.out.println("----------- Part-3 -----------");
		int one = 10, two = 20;
		int sum = DemoScopes(one, two);
		System.out.println(sum);

		// Part-4
		System.out.println("----------- Part-4 -----------");
		System.out.println(abc);
		int abc = 200;
		System.out.println(abc);
		System.out.println(FunctionDemo.abc);
		DemoGlobalScopes(one);

		// Part 5 - Pass by value
		System.out.println("----------- Part-5 -----------");
		System.out.println(one + ", " + two);
		Swap(one, two);
		System.out.println(one + ", " + two);

	}

	public static void Swap(int one, int two) {
		System.out.println(one + ", " + two);

		int temp = one;
		one = two;
		two = temp;

		System.out.println(one + ", " + two);
	}

	public static int DemoGlobalScopes(int one) {
		abc = abc + 40;
		int abc = 30;
		abc = abc + 80;
		int sum = one + abc;
		return sum;
	}

	public static int DemoScopes(int one, int another) {

		int sum = one + another;
		return sum;
	}

	public static int additionWithParams(int a, int b, int c, int d) {

		int sum = a + b;
		return sum;
	}

	public static int additionRV() {
		
		int a = 2;
		int b = 3;
		int sum = a + b;

		return sum;

		// System.out.println("hii");
	}

	public static void addition() {
		
		int a = 2;
		int b = 3;
		int sum = a + b;
		System.out.println(sum);

		System.out.println("bye add");
	}

	public static int subtraction() {
		int a = 7;
		int b = 3;
		int sub = a - b;
		return sub;
	}

}

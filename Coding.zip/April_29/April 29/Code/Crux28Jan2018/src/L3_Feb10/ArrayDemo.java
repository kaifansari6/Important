package L3_Feb10;

/**
 * @author Garima Chhikara
 * @date 10-Feb-2018
 */

public class ArrayDemo {

	public static void main(String[] args) {

		// array declare
		int[] arr = null;
		arr = new int[5];

		int[] arr1 = arr;
		System.out.println(arr);

		// get
		System.out.println(arr[0]);
		System.out.println(arr[1]);
		System.out.println(arr[2]);
		System.out.println(arr[3]);
		System.out.println(arr[4]);
		// System.out.println(arr[5]);

		// set
		arr[0] = 10;
		arr[1] = 20;
		arr[2] = 30;
		arr[3] = 40;
		arr[4] = 50;

		// get
		System.out.println(arr[0]);
		System.out.println(arr[1]);
		System.out.println(arr[2]);
		System.out.println(arr[3]);
		System.out.println(arr[4]);

		// print
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
			// arr[i] = 100;
		}

		// enhanced for loop
		for (int val : arr) {
			System.out.println(val);
		}

		int i = 0, j = 2;

		// non working swap
		System.out.println(arr[i] + ", " + arr[j]);
		Swap(arr[i], arr[j]);
		System.out.println(arr[i] + ", " + arr[j]);

		// working swap
		System.out.println(arr[i] + ", " + arr[j]);
		Swap(arr, i, j);
		System.out.println(arr[i] + ", " + arr[j]);

		int[] other = { 100, 200, 300 };
		System.out.println(arr[0] + ", " + other[0]);
		Swap(arr, other);
		System.out.println(arr[0] + ", " + other[0]);
	}

	public static void Swap(int[] one, int[] two) {
		int[] temp = one;
		one = two;
		two = temp;
		// System.out.println(one[0] + ", " + two[0]);
	}

	public static void Swap(int[] arr1, int i, int j) {
		System.out.println(arr1[i] + ", " + arr1[j]);

		int temp = arr1[i];
		arr1[i] = arr1[j];
		arr1[j] = temp;

		System.out.println(arr1[i] + ", " + arr1[j]);
	}

	public static void Swap(int one, int two) {
		int temp = one;
		one = two;
		two = temp;
	}

}

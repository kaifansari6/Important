package L3_Feb10;

import java.util.Scanner;

/**
 * @author Garima Chhikara
 * @date 10-Feb-2018
 */

public class FunctionOps {

	public static void main(String[] args) {

		Scanner scn = new Scanner(System.in);
		int ll = scn.nextInt();
		int ul = scn.nextInt();

		// printAllPrimes(ll, ul);
		printAllArmstrong(ll, ul);

	}

	public static void printAllPrimes(int ll, int ul) {

		for (int i = ll; i <= ul; i++) {
			if (isPrime(i))
				System.out.println(i);
		}
	}

	public static boolean isPrime(int num) {

		boolean flag = true;

		int div = 2;
		while (div * div <= num) {

			if (num % div == 0) {
				flag = false;
				break;
			}
			div++;
		}

		return flag;
	}

	public static void printAllArmstrong(int ll, int ul) {

		for (int i = ll; i <= ul; i++) {
			int nod = noOfDigits(i);
			if (isArmstrong(i, nod))
				System.out.println(i);
		}
	}

	public static boolean isArmstrong(int num, int numberOfDigits) {

		int temp = num;
		int ans = 0;
		while (num != 0) {

			int rem = num % 10;
			ans = ans + (int) Math.pow(rem, numberOfDigits);
			num = num / 10;
		}

		if (ans == temp) {
			return true;
		} else {
			return false;
		}
	}

	public static int noOfDigits(int num) {

		int count = 0;

		while (num != 0) {

			count++;
			num = num / 10;
		}

		return count;
	}

	// public static int power(int x, int n) {
	//
	// }
	//
	// public static int log(int x, int n) {
	//
	// }
	//
	// public static int gcd(int num1, int num2) {
	//
	// }
	//
	// public static int lcm(int num1, int num2) {
	//
	// }

}

package L6_Feb18;

import java.util.Scanner;

/**
 * @author Garima Chhikara
 * @date 18-Feb-2018
 */

public class StringOps {

	public static void main(String[] args) {

		Scanner scn = new Scanner(System.in);
		// String str = scn.nextLine();

		// System.out.println(str);

		// printChars(str);
		printPalindromicSubstrings("nitin");

	}

	public static void printChars(String str) {

		for (int i = 0; i < str.length(); i++) {
			System.out.println(str.charAt(i));
		}
	}

	public static boolean isPalindrome(String str) {

		int left = 0;
		int right = str.length() - 1;

		while (left < right) {

			if (str.charAt(left) != str.charAt(right)) {
				return false;
			}

			left++;
			right--;
		}

		return true;
	}

	public static void printSubstrings(String str) {

		for (int si = 0; si < str.length(); si++) {

			for (int ei = si + 1; ei <= str.length(); ei++) {
				String ss = str.substring(si, ei);
				System.out.println(ss);
			}
		}
	}

	public static void printPalindromicSubstrings(String str) {

		for (int si = 0; si < str.length(); si++) {

			for (int ei = si + 1; ei <= str.length(); ei++) {
				String ss = str.substring(si, ei);

				if (isPalindrome(ss))
					System.out.println(ss);
			}
		}

	}

}

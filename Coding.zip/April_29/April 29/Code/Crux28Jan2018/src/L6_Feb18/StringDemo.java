package L6_Feb18;

/**
 * @author Garima Chhikara
 * @date 18-Feb-2018
 */

public class StringDemo {

	public static void main(String[] args) {

		String str = "HelloWorld";

		// Part-1 : Length of String
		System.out.println(str.length());

		// Part-2 : CharAt Limit:0->length-1
		char ch = str.charAt(0);
		System.out.println(ch);
		// System.out.println(str.charAt(str.length()));
		System.out.println(str.charAt(str.length() - 1));

		// Part-3 : Substring Limit:0->length
		System.out.println(str.substring(2, 4)); // ll
		System.out.println(str.substring(0, 3)); // Hel
		System.out.println(str.substring(0, 8)); // Hellowor
		System.out.println(str.substring(0, 5)); // Hello
		System.out.println(str.substring(3, 4)); // l
		System.out.println(str.substring(4, 4)); // blank
		System.out.println(str.substring(1)); // elloWorld
		// System.out.println(str.substring(5, 4)); // exception

		// Part-4 : Concatenate Two Strings
		String s1 = "hi";
		String s2 = "bye";
		String s3 = s1 + s2;
		System.out.println(s1 + ", " + s2 + ", " + s3);
		String s4 = s1.concat(s2);
		System.out.println(s1 + ", " + s2 + ", " + s4);

		// Part-5 : IndexOf
		System.out.println(str.indexOf("el"));
		System.out.println(str.indexOf("eL"));

		// Part-6 : StartsWith
		System.out.println(str.startsWith("He"));
		System.out.println(str.startsWith("he"));

		// Part-7 : Equals and ==
		s1 = "Hello";
		s2 = s1;
		s3 = "Hello";
		s4 = new String("Hello");

		System.out.println((s1 == s2) + ", " + s1.equals(s2)); // true true
		System.out.println((s1 == s3) + ", " + s1.equals(s3)); // true true
		System.out.println((s1 == s4) + ", " + s1.equals(s4)); // false true

		str = str.replace('l', 'a');
		System.out.println(str);

		String str10 = "Hello";
		String str11 = "HelloBye";
		String str12 = str11.substring(0, 5);
		System.out.println(str10 + " , " + str12);

		appendString();
	}

	public static void appendString() {

		long start = System.currentTimeMillis();

		// String str = "";
		StringBuilder sb = new StringBuilder() ;
		int str = 0;
		for (int i = 0; i < 100000; i++) {
//			str += i;
			sb.append(i) ;
		}

		long end = System.currentTimeMillis();

		System.out.println(end - start);
	}

}

package L6_Feb18;

import java.util.ArrayList;

/**
 * @author Garima Chhikara
 * @date 18-Feb-2018
 */

public class ArrayListOps {

	public static void main(String[] args) {

		int[] one = { 10, 10, 20, 40, 40, 50, 50 };
		int[] two = { 10, 10, 10, 30, 40, 50, 50, 50, 60 };
		System.out.println(intersection(one, two));

		int[] arr1 = { 9, 9, 9 };
		int[] arr2 = { 9, 9, 9, 9, 9, 9 };
		System.out.println(sumOfArrays(arr1, arr2));
	}

	public static ArrayList<Integer> intersection(int[] one, int[] two) {

		ArrayList<Integer> ans = new ArrayList<>();

		int i = 0;
		int j = 0;

		while (i < one.length && j < two.length) {

			if (one[i] < two[j]) {
				i++;
			} else if (one[i] > two[j]) {
				j++;
			} else {
				ans.add(one[i]);
				i++;
				j++;
			}

		}

		return ans;
	}

	public static ArrayList<Integer> sumOfArrays(int[] one, int[] two) {

		ArrayList<Integer> ans = new ArrayList<>();
		int i = one.length - 1;
		int j = two.length - 1;
		int carry = 0;

		while (i >= 0 || j >= 0) {

			int sum = carry;

			if (i >= 0)
				sum += one[i];

			if (j >= 0)
				sum += two[j];

			int rem = sum % 10;
			ans.add(0, rem);
			carry = sum / 10;

			i--;
			j--;
		}
		if (carry != 0)
			ans.add(0, carry);

		return ans;
	}

}

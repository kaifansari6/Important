
/**
 * @author Garima Chhikara
 * @date Jan 28, 2018
 */

public class Test {

	public static void main(String[] args) {

		// System.out.print("Hello World");
		// System.out.print("\n");
		// System.out.print("Hello World");
		// System.out.print("\n");
		// System.out.print("Hello World");

		System.out.println("Hello World");
		System.out.println("Hello World");
		System.out.println("Hello World");

	}

}

package L2_Feb3;

public class DecimalToBinary {

	public static void main(String[] args) {

		int decimal = 37;
		int power = 1;
		int binary = 0;

		while (decimal != 0) {

			int rem = decimal % 2;
			binary = binary + (rem * power);

			power = power * 10;
			decimal = decimal / 2;

			// System.out.println(binary);

		}

		System.out.println(binary);

	}

}

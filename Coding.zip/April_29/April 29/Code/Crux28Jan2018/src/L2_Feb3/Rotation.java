package L2_Feb3;

import java.util.Scanner;

public class Rotation {

	public static void main(String[] args) {
		
		Scanner scn = new Scanner(System.in) ;
		
		int n = scn.nextInt() ;
		int temp = n ;
		int r =  scn.nextInt() ;
		
		// no of digits
		int nod = 0 ;
		while(temp != 0) {
			temp = temp/ 10 ;
			nod ++ ;
		}
		
		r = r % nod ;
		if(r < 0)
			r = r + nod ;
		
		// rotation
		int divisor = (int) Math.pow(10, r) ;
		int rem = n  % divisor ;
		int quotient = n / divisor ;
		
		int multiplier = (int) Math.pow(10, nod - r) ;
		int ans = rem*multiplier + quotient ;
		
		System.out.println(ans);

	}

}

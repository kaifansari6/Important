package L2_Feb3;

public class Q13 {

	public static void main(String[] args) {

		int n = 5;

		int nr = 2 * n - 1;
		int nst = 1;

		for (int row = 1; row <= nr; row++) {

			// stars
			for (int cst = 1; cst <= nst; cst++) {
				System.out.print("*");
			}

			// row prep
			System.out.println();
			if (row <= nr / 2)
				nst = nst + 1;
			else
				nst = nst - 1;
		}

	}

}

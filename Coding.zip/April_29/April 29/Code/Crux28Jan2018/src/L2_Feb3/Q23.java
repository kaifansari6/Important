package L2_Feb3;

public class Q23 {

	public static void main(String[] args) {

		int n = 5;
		int nst = 1;
		int nsp = n - 1;

		for (int row = 1; row <= n; row++) {
			int val = row;

			for (int csp = 1; csp <= nsp; csp++) {
				System.out.print("\t");
			}

			for (int cst = 1; cst <= nst; cst++) {
				// System.out.print(val + "\t");
				// if (cst <= nst / 2)
				// val++;
				// else
				// val--;

				if (cst == 1 || cst == nst)
					System.out.print(row + "\t");
				else
					System.out.print(0 + "\t");
			}

			System.out.println();

			nst += 2;
			nsp--;

		}

	}

}

package L2_Feb3;

public class Q15 {

	public static void main(String[] args) {
	
		int n = 5 ;
		int nr = 2 *n -1 ;
		int nst = nr/2 +1 ;
		int nsp = 0 ;
		
		for(int row =1 ; row <= nr ; row++) {
			
			for(int csp = 1 ; csp <= nsp ; csp++) {
				System.out.print(" ");
			}
			
			for(int cst = 1 ; cst <= nst ; cst++) {
				System.out.print("*");
			}
			
			System.out.println();
			if(row <= nr/2) {
				nst--;
				nsp+=2 ;
			}else {
				nst++;
				nsp-=2 ;
			}
			
		}

	}

}

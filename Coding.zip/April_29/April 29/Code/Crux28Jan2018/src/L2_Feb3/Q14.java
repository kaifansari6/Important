package L2_Feb3;

public class Q14 {

	public static void main(String[] args) {

		int n = 5;

		int nr = 2 * n - 1;
		int nst = 1;
		int nsp = nr / 2;

		for (int row = 1; row <= nr; row++) {

			// spaces
			for (int csp = 1; csp <= nsp; csp++) {
				System.out.print(" ");
			}

			// stars
			for (int cst = 1; cst <= nst; cst++) {
				System.out.print("*");
			}

			// row prep
			System.out.println();
			if (row <= nr / 2) {
				nst++;
				nsp--;
			} else {
				nst--;
				nsp++;
			}
		}

	}

}

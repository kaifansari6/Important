package L2_Feb3;

public class Q17 {

	public static void main(String[] args) {
	
		int n = 9 ;
		int nst = n/2 ;
		int nsp = 1 ;
		
		for(int row =1 ; row <= n ; row++) {
			
			for(int cst = 1 ; cst <= nst ; cst++) {
				System.out.print("*");
			}
			
			for(int csp = 1 ; csp <= nsp ; csp++) {
				System.out.print(" ");
			}
			
			for(int cst = 1 ; cst <= nst ; cst++) {
				System.out.print("*");
			}
			
			System.out.println();
			if(row <= n/2) {
				nst--;
				nsp+=2 ;
			}else {
				nst++;
				nsp-=2 ;
			}
			
		}

	}

}

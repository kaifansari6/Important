package L4_Feb11;

import java.util.Scanner;

/**
 * @author Garima Chhikara
 * @date 11-Feb-2018
 */

public class ArrayOps {

	static Scanner scn = new Scanner(System.in);

	public static void main(String[] args) {

		// int[] array = takeInput();
		// int[] array = { 2, 4, 3, 0, 1 };
		// int[] array = { 10, 20, 30, 40, 50, 60, 70, 80, 90 };
		int[] array = { 50, 40, 30, 20, 10 };
		display(array);
		// System.out.println(maximum(array));
		// System.out.println(linearSearch(array, 300));
		// reverse(array);
		// display(array);

		// array = rotate(array, 4);
		// array = inverse(array);
		// display(array);
		// System.out.println(binarySearch(array, 40));
		insertionSort(array);
		display(array);
	}

	public static int[] takeInput() {

		System.out.println("n ?");
		int n = scn.nextInt();

		int[] arr = new int[n];

		for (int i = 0; i < arr.length; i++) {
			arr[i] = scn.nextInt();
		}

		return arr;
	}

	public static void display(int[] arr) {

		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println();
	}

	public static int maximum(int[] arr) {

		int max = Integer.MIN_VALUE;

		for (int i = 0; i < arr.length; i++) {
			if (arr[i] > max) {
				max = arr[i];
			}
		}

		return max;

	}

	public static int linearSearch(int[] arr, int item) {

		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == item) {
				return i;
			}
		}

		return -1;
	}

	public static int binarySearch(int[] arr, int item) {

		int left = 0;
		int right = arr.length - 1;

		while (left <= right) {

			int mid = (left + right) / 2;

			if (item < arr[mid]) {
				right = mid - 1;
			} else if (item > arr[mid]) {
				left = mid + 1;
			} else {
				return mid;
			}
		}

		return -1;

	}

	public static void reverse(int[] arr) {

		int left = 0;
		int right = arr.length - 1;

		while (left < right) {
			int temp = arr[left];
			arr[left] = arr[right];
			arr[right] = temp;

			left++;
			right--;
		}
	}

	public static int[] rotate(int[] arr, int k) {

		int[] ans = new int[arr.length];

		k = k % arr.length;
		if (k < 0)
			k = k + arr.length;

		for (int i = 0; i < ans.length; i++) {

			if (i < k) {
				ans[i] = arr[i + ans.length - k];
			} else {
				ans[i] = arr[i - k];
			}
		}

		return ans;
	}

	public static int[] inverse(int[] arr) {
		int[] inv = new int[arr.length];

		for (int i = 0; i < inv.length; i++) {

			inv[arr[i]] = i;
		}
		return inv;
	}

	public static void bubbleSort(int[] arr) {

	
		for (int counter = 0; counter < arr.length - 1; counter++) {

			boolean flag = true ;
//			System.out.println("Counter " + counter + ":");
			for (int j = 0; j < arr.length - 1 - counter; j++) {

				if (arr[j] > arr[j + 1]) {
					flag = false ;
					int temp = arr[j];
					arr[j] = arr[j + 1];
					arr[j + 1] = temp;
				}
//				display(arr);
			}
			
			if(flag) {
				break ;
			}

		}
	}

	public static void selectionSort(int[] arr) {

		for (int counter = 0; counter < arr.length - 1; counter++) {

			int min = counter;

			for (int j = counter + 1; j <= arr.length - 1; j++) {

				if (arr[j] < arr[min]) {
					min = j;
				}
			}

			if (min != counter) {
				int temp = arr[counter];
				arr[counter] = arr[min];
				arr[min] = temp;
			}
		}
	}

	public static void insertionSort(int[] arr) {

		for (int counter = 1; counter <= arr.length - 1; counter++) {

			int val = arr[counter];

			int j = counter - 1;
			while (j >= 0 && arr[j] > val) {
				arr[j + 1] = arr[j];
				j--;
			}

			arr[j + 1] = val;
		}
	}

}

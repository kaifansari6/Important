
/**
 * @author Garima Chhikara
 * @date Jan 28, 2018
 */

public class Q11 {

	public static void main(String[] args) {

		int n = 5;
		int nst = 1;
		int nsp = n - 1;

		int row = 1;
		while (row <= n) {

			// self work for spaces
			int csp = 1;
			while (csp <= nsp) {
				System.out.print(" ");
				csp = csp + 1;
			}

			// stars
			int cst = 1;
			while (cst <= nst) {
				if (cst % 2 == 0) {
					System.out.print(" ");
				} else {
					System.out.print("*");
				}
				cst = cst + 1;
			}

			// next row preparation
			System.out.println();
			nst = nst + 2;
			nsp = nsp - 1;
			row = row + 1;
		}
	}

}

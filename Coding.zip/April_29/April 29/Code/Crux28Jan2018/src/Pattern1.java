
/**
 * @author Garima Chhikara
 * @date Jan 28, 2018
 */

public class Pattern1 {

	public static void main(String[] args) {

		int n = 5;
		int nst = 1;

		int row = 1;
		while (row <= n) {

			int cst = 1;
			while (cst <= nst) {
				System.out.print("*");
				cst = cst + 1;
			}

			// next row preparation
			System.out.println();
			nst = nst + 1;
			row = row + 1;
		}
	}

}

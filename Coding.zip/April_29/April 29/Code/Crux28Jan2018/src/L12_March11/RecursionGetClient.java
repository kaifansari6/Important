package L12_March11;

import java.util.ArrayList;

/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 * @date 11-Mar-2018
 */

public class RecursionGetClient {

	public static void main(String[] args) {

		ArrayList<String> list = new ArrayList<>();
		String s = "";
		list.add(s);

		String str = "hello";
		System.out.println(str.charAt(0));
		String ss = str.substring(1);

	}

}

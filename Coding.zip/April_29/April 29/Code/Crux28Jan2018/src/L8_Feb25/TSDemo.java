package L8_Feb25;

import javax.swing.plaf.synth.SynthSeparatorUI;

/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 * @date 25-Feb-2018
 */

public class TSDemo {

	public static void main(String[] args) {

		int[] arr = new int[100000];

		for (int i = 0; i < arr.length; i++) {
			arr[i] = arr.length - i;
		}

		long start = System.currentTimeMillis();

		 L4_Feb11.ArrayOps.bubbleSort(arr);

//		L7_Feb24.RecursionDemo.mergeSort(arr, 0, arr.length - 1);
		long end = System.currentTimeMillis();

		System.out.println(end - start);
	}

}

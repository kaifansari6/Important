package L8_Feb25;

import java.util.Arrays;
import java.util.Scanner;

import L7_Feb24.RecursionDemo;

/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 * @date 03-Mar-2018
 */

public class TnSQs {

	public static void main(String[] args) {

		Scanner scn = new Scanner(System.in);
		int x = scn.nextInt();
		int n = scn.nextInt();

		// System.out.println(polynomialEval(x, n));

		// System.out.println(power(x, n));

		// System.out.println(countPalindromicSS("aabaa"));
		SOE(25);
	}

	public static int polynomialEval(int x, int n) {

		// int limit = n ;
		// int ans = 0 ;
		//
		// for(int coeff = 1 ; coeff <= n ; coeff++) {
		//
		// int p = RecursionDemo.power(x, limit) ;
		// limit-- ;
		// ans = ans + coeff * p ;
		// }

		int ans = 0;
		int mult = x;
		for (int coeff = n; coeff >= 1; coeff--) {

			ans = ans + coeff * mult;

			mult = mult * x;
		}

		return ans;
	}

	public static int power(int x, int n) {

		if (n == 0) {
			return 1;
		}

		int ans;
		int p = power(x, n / 2);
		if (n % 2 == 0) {
			ans = p * p;
		} else {
			ans = x * p * p;
		}

		return ans;
	}

	public static int countPalindromicSS(String str) {

		int count = 0;

		// odd length
		for (int axis = 0; axis < str.length(); axis++) {

			for (int orbit = 0; axis - orbit >= 0 && axis + orbit < str.length(); orbit++) {

				if (str.charAt(axis + orbit) == str.charAt(axis - orbit)) {
					count++;
				} else {
					break;
				}
			}
		}

		// even
		for (double axis = 0.5; axis < str.length(); axis++) {

			for (double orbit = 0.5; axis - orbit >= 0 && axis + orbit < str.length(); orbit++) {

				if (str.charAt((int) (axis + orbit)) == str.charAt((int) (axis - orbit))) {
					count++;
				} else {
					break;
				}
			}
		}

		return count;
	}

	public static void SOE(int n) {

		boolean[] primes = new boolean[n + 1];
		Arrays.fill(primes, true);

		primes[0] = false;
		primes[1] = false;

		for (int table = 2; table * table <= n; table++) {

			if (primes[table] == false) {
				continue;
			}

			for (int multiplier = 2; table * multiplier <= n; multiplier++) {

				primes[table * multiplier] = false;
			}

		}

		for (int i = 0; i < primes.length; i++) {
			if (primes[i]) {
				System.out.println(i);
			}
		}

	}

}

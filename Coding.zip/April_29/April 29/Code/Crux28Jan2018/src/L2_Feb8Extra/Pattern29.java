package L2_Feb8Extra;

/**
 * @author Garima Chhikara
 * @date 08-Feb-2018
 */

public class Pattern29 {

	public static void main(String[] args) {

		int n = 5;
		int nst = 1;
		int nsp = n - 1;
		
		for (int row = 1; row <= n; row++) {
			for (int csp = 1; csp <= nsp; csp++) {
				System.out.print(" ");
			}

			for (int cst = 1; cst <= nst; cst++) {
				if(cst == 1 || cst == nst)
					System.out.print(row);
				else
					System.out.print(0);
			}

			nst += 2;
			nsp--;
			System.out.println();
		}

	}

}

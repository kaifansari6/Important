package L2_Feb8Extra;

/**
 * @author Garima Chhikara
 * @date 08-Feb-2018
 */

public class A2Q9 {

	public static void main(String[] args) {
		int n = 5;
		int nst = 1;

		for (int row = 0; row < n; row++) {

			int val = 1;

			for (int col = 0; col <= row; col++) {
				System.out.print(val + "\t");
				val = (val * (row - col)) / (col + 1);
			}

			nst++;
			System.out.println();
		}

	}

}

package L2_Feb8Extra;

/**
 * @author Garima Chhikara
 * @date 08-Feb-2018
 */

public class A2Q10 {

	public static void main(String[] args) {
		int n = 5;
		int a = 0 ;
		int b = 1;

		for (int row = 0; row < n; row++) {

			for (int col = 0; col <= row; col++) {
				System.out.print(a + "\t");
				int sum = a+b ;
				a = b;
				b = sum ;
				
			}
			
			System.out.println();
		}

	}

}

package L2_Feb8Extra;

/**
 * @author Garima Chhikara
 * @date 08-Feb-2018
 */

public class Pattern1 {

	public static void main(String[] args) {

		int n = 5;

		for (int row = 1; row <= n; row++) {

			System.out.print("*");

			System.out.println();
		}

	}

}

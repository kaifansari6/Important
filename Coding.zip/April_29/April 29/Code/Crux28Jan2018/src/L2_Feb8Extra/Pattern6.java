package L2_Feb8Extra;

/**
 * @author Garima Chhikara
 * @date 08-Feb-2018
 */

public class Pattern6 {

	public static void main(String[] args) {

		int n = 5;
		int nst = n ;
		int nsp = 0 ;
		
		for (int row = 1; row <= n; row++) {

			for(int csp = 1 ; csp <= nsp ; csp++) {
				System.out.print(" ");
			}
			
			for(int cst = 1 ; cst <= nst ; cst++) {
				System.out.print("*");
			}

			nst-- ;
			nsp+=2 ;
			System.out.println();
		}

	}

}

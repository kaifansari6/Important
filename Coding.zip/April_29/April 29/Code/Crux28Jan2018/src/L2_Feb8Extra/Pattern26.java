package L2_Feb8Extra;

/**
 * @author Garima Chhikara
 * @date 08-Feb-2018
 */

public class Pattern26 {

	public static void main(String[] args) {

		int n = 5;
		int nst = 1;
		int nsp = n - 1;
		int val = 1;

		for (int row = 1; row <= n; row++) {
			val = 1;
			for (int csp = 1; csp <= nsp; csp++) {
				System.out.print(" ");
			}

			for (int cst = 1; cst <= nst; cst++) {
				System.out.print(val);
				if (cst <= nst / 2)
					val++;
				else
					val-- ;
			}

			nst += 2;
			nsp--;
			System.out.println();
		}

	}

}

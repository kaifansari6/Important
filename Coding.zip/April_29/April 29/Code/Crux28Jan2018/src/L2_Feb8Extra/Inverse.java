package L2_Feb8Extra;

/**
 * @author Garima Chhikara
 * @date 08-Feb-2018
 */

public class Inverse {

	public static void main(String[] args) {
		
		int n = 25413 ;
		int count = 1;
		int ans = 0 ;
		
		while(n != 0) {
			
			int rem = n % 10 ;
			int multiplier = (int) Math.pow(10, rem-1) ;
			ans = ans + (count * multiplier) ;
			
			count ++ ;
			n = n / 10 ;
		}
		
		System.out.println(ans);
		
	}

}

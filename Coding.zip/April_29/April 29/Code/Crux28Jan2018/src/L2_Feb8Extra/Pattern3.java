package L2_Feb8Extra;

/**
 * @author Garima Chhikara
 * @date 08-Feb-2018
 */

public class Pattern3 {

	public static void main(String[] args) {

		int n = 5;
		int nst = 1 ;
		
		for (int row = 1; row <= n; row++) {

			for(int cst = 1 ; cst <= nst ; cst++) {
				System.out.print("*");
			}

			nst++ ;
			System.out.println();
		}

	}

}

package L2_Feb8Extra;

/**
 * @author Garima Chhikara
 * @date 08-Feb-2018
 */

public class Pattern7 {

	public static void main(String[] args) {

		int n = 5;

		for (int row = 1; row <= n; row++) {

			for (int col = 1; col <= n; col++) {

				if (row == 1 || row == n || col == 1 || col == n)
					System.out.print("*");
				else
					System.out.print(" ");
			}

			System.out.println();
		}

	}

}

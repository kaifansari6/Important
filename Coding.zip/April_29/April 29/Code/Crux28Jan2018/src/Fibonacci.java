import java.util.Scanner;

/**
 * @author Garima Chhikara
 * @date Jan 28, 2018
 */

public class Fibonacci {

	public static void main(String[] args) {

		Scanner scn = new Scanner(System.in);
		int n = scn.nextInt();

		int a = 0;
		int b = 1;
		int counter = 0;

		while (counter <= n) {

			System.out.print(a + " ");
			int sum = a + b;
			a = b;
			b = sum;

			counter++;
		}
	}
}

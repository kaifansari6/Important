
/**
 * @author Garima Chhikara
 * @date Jan 28, 2018
 */

public class LoopDemo {

	public static void main(String[] args) {

		// System.out.println("HW");
		// System.out.println("HW");
		// System.out.println("HW");
		// System.out.println("HW");
		// System.out.println("HW");

		int counter = 1;
		while (counter <= 5) {
			System.out.println("HW");
			counter = counter + 1;
		}

	}

}

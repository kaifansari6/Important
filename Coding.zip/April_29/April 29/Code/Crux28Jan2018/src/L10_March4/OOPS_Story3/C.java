package L10_March4.OOPS_Story3;

/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 * @date 04-Mar-2018
 */

public class C extends P {

	int d = 20;
	int d2 = 200;

	public void fun() {
		System.out.println("in C fun");
		// super.fun();
	}

	public void fun2() {
		System.out.println("in C fun2");
	}
}

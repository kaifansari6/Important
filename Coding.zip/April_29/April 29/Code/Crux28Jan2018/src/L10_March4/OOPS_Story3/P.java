package L10_March4.OOPS_Story3;

/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 * @date 04-Mar-2018
 */

public class P {

	int d = 10 ;
	int d1 = 100 ;
	
	public void fun() {
		System.out.println("in P fun");
	}
	
	public void fun1() {
		System.out.println("in P fun1");
	}
}

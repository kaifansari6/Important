package L10_March4.OOPS_Story3;

/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 * @date 04-Mar-2018
 */

public class Client {

	public static void main(String[] args) {

		// Case 1
		System.out.println("Case 1");
		P obj1 = new P();
		System.out.println(obj1.d);
		System.out.println(obj1.d1);
		// System.out.println(obj1.d2);
		obj1.fun();
		obj1.fun1();

		// Case 2
		System.out.println("Case 2");
		P obj2 = new C();
		System.out.println(obj2.d);
		System.out.println(((C) obj2).d);
		System.out.println(obj2.d1);
		System.out.println(((C) obj2).d2);
		obj2.fun();
		((P) obj2).fun();
		obj2.fun1();
		((C) obj2).fun2();

		// Case 3
		System.out.println("Case 3");
		// C obj3 = new P();
		// System.out.println(obj3.d2);

		// Case 4
		System.out.println("Case 4");
		C obj4 = new C();
		System.out.println(obj4.d);
		System.out.println(((P) obj4).d);
		System.out.println(obj4.d1);
		System.out.println(obj4.d2);
		obj4.fun();
		((P) obj4).fun();
		obj4.fun1();
		obj4.fun2();
	}

}

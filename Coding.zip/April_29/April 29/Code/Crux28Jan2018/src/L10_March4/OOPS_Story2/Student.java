package L10_March4.OOPS_Story2;

/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 * @date 04-Mar-2018
 */

public class Student {

	private String name;
	private int rollNo;

	public void setName(String name) throws Exception {
		
		if(name == null) {
			throw new Exception("Invalid Name") ;
		}
		this.name = name;
	}

	public String getName() {
		return this.name;
	}
}

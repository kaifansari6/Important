package L10_March4.OOPS_Story2;

/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 * @date 04-Mar-2018
 */

public class StudentClient {

	public static void main(String[] args) {

		Student s = new Student();
		try {
			s.setName(null);

			System.out.println("bye try");
			// } catch (ArrayIndexOutOfBoundsException e) {
			// System.out.println("array index catch");
			// } catch (NullPointerException e) {
			// System.out.println("null catch");
		} catch (Exception e) {
			System.out.println("in e");
			// return;
		} finally {
			System.out.println("in final");
		}
		System.out.println("bye");
	}

}

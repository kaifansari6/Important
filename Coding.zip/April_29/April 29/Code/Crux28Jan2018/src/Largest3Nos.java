
/**
 * @author Garima Chhikara
 * @date Jan 28, 2018
 */

public class Largest3Nos {

	public static void main(String[] args) {

		int a = 20;
		int b = 20;
		int c = 10;

		// if (a >= b && a >= c) {
		// System.out.println("a");
		// } else {
		// if (b >= a && b >= c) {
		// System.out.println("b");
		// } else {
		// System.out.println("c");
		// }
		// }

		if (a >= b && a >= c) {
			System.out.println("a");
		} else if (b >= a && b >= c) {
			System.out.println("b");
		} else {
			System.out.println("c");
		}

	}

}

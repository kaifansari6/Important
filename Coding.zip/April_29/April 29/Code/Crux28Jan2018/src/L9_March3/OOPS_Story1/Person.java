package L9_March3.OOPS_Story1;

/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 * @date 03-Mar-2018
 */

public class Person {

	String name = "xyz";
	int age = 100;

	// default constructor
	public Person() {
		this.name = "mohit";
		this.age = 110;
	}

	// parameterized constructor
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}

	public void sayHi(String name) {
		System.out.println(this.name + " says hii to " + name);
	}

	public void introduceYourself() {
		System.out.println("My name is " + name);
	}

	@Override
	public String toString() {
		return this.name + "@" + this.age;
	}

}

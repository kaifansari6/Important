package L9_March3.OOPS_Story1;

/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 * @date 03-Mar-2018
 */

public class PersonClient {

	public static void main(String[] args) {

		Person p = new Person();
		// System.out.println(p);

		System.out.println(p.name);
		System.out.println(p.age);

		p.name = "Amit";
		p.age = 20;

		System.out.println(p.name);
		System.out.println(p.age);

		Person p1 = p;
		System.out.println(p1.name);
		System.out.println(p1.age);

		p1.name = "Rohit";
		p1.age = 30;

		// Person p2 = new Person();
		// p2.name = "abc";
		// p2.age = 40;

		Person p3 = new Person();
		p3.age = 10;
		p3.name = "A";

		Person p4 = new Person();
		p4.age = 20;
		p4.name = "B";

		// Test1(p3, p4);
		System.out.println(p3.age + " " + p3.name);
		System.out.println(p4.age + " " + p4.name);
		// Test2(p3, p4);
		System.out.println(p3.age + " " + p3.name);
		System.out.println(p4.age + " " + p4.name);

		int myAge = 30;
		String myName = "C";

		Test3(p3, p4.age, p4.name, myAge, myName);
		System.out.println(p3.age + " " + p3.name);
		System.out.println(p4.age + " " + p4.name);
		System.out.println(myAge + " " + myName);

		p1.sayHi("Varun");
		// p1.introduceYourself();

		Person p5 = null;

		System.out.println(p5);

		p5.age = -1;

	}

	public static void Test3(Person p, int age, String name, int myAge, String myName) {
		p.age = 0;
		p.name = "_";
		age = 0;
		name = "_";
		myAge = 0;
		myName = "_";
	}

	public static void Test2(Person p1, Person p2) {

		p2 = new Person();
		int tempa = p1.age;
		p1.age = p2.age;
		p2.age = tempa;

		p1 = new Person();
		String tempn = p1.name;
		p1.name = p2.name;
		p2.name = tempn;
	}

	public static void Test1(Person p1, Person p2) {
		Person temp = p1;
		p1 = p2;
		p2 = temp;
	}
}

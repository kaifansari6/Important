package L5_Feb17;

import java.util.ArrayList;

/**
 * @author Garima Chhikara
 * @date 17-Feb-2018
 */

public class ArrayListDemo {

	public static void main(String[] args) {

		ArrayList<Integer> list = new ArrayList<>();

		// add elements in list
		System.out.println(list);
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);
		System.out.println(list);

		// size of list
		System.out.println(list.size());

		// get the elements
		System.out.println(list.get(0));
		System.out.println(list.get(1));
		System.out.println(list.get(2));
		System.out.println(list.get(3));
		// System.out.println(list.get(5)) ;

		// set the element
		list.set(0, 11);
		list.set(1, 22);
		list.set(2, 33);
		list.set(3, 44);

		System.out.println(list);
		list.add(2, 55);
		System.out.println(list.size());
		list.add(list.size(), 66);
		System.out.println(list);

		// remove the element
		list.remove(1);
		System.out.println(list);

		// print using index
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
		}

		// print using enhanced loop
		for (int val : list) {
			System.out.println(val);
		}

	}

}

package L5_Feb17;

/**
 * @author Garima Chhikara
 * @date 17-Feb-2018
 */

public class Array2DDemo {

	public static void main(String[] args) {

		int[][] arr;
		arr = new int[3][5];

		// print an array
		System.out.println(arr);

		// get value
		System.out.println(arr[0]);
		System.out.println(arr[1]);
		System.out.println(arr[2]);
		// System.out.println(arr[4]);

		// row : arr.length
		System.out.println(arr.length);

		// col : arr[0].length
		System.out.println(arr[0].length);

		// print a value
		System.out.println(arr[0][2]);

		// jagged array
		int[][] jarr = new int[3][];

		// print jarr
		System.out.println(jarr);

		// get the value
		System.out.println(jarr[0]);
		System.out.println(jarr[1]);
		System.out.println(jarr[2]);

		jarr[0] = new int[2];
		jarr[1] = new int[5];
		jarr[2] = new int[6];

		System.out.println(jarr[0]);
		System.out.println(jarr[1]);
		System.out.println(jarr[2]);

		System.out.println(jarr.length);
		System.out.println(jarr[0].length);
		System.out.println(jarr[1].length);
		System.out.println(jarr[2].length);

	}

}

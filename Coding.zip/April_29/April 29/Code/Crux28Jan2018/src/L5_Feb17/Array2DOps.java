package L5_Feb17;

import java.util.Scanner;

/**
 * @author Garima Chhikara
 * @date 17-Feb-2018
 */

public class Array2DOps {

	static Scanner scn = new Scanner(System.in);

	public static void main(String[] args) {

		// int[][] arr = takeInput();
		// display(arr);

		int[][] arr = { { 10, 20, 30, 40 }, { 50, 60, 70, 80 }, { 90, 100, 110, 120 }, { 130, 140, 150, 160 } };
		// display(arr);
		// spiralDisplay(arr);

		int[][] one = { { 1, 2, 3 }, { 4, 5, 6 } };
		int[][] two = { { 7, 8, 9, 10, 11 }, { 12, 13, 14, 15, 16 }, { 17, 18, 19, 20, 21 } };

		int[][] ans = matrixMultiplication(one, two);
		display(ans);
	}

	// input for jagged array
	public static int[][] takeInput() {

		System.out.println("Rows ?");
		int rows = scn.nextInt();

		int[][] arr = new int[rows][];

		for (int row = 0; row < arr.length; row++) {

			System.out.println("Col for " + row + "th row ?");
			int cols = scn.nextInt();

			arr[row] = new int[cols];

			// array fill
			for (int col = 0; col < arr[row].length; col++) {
				System.out.println("[" + row + ", " + col + "]");
				arr[row][col] = scn.nextInt();
			}
		}

		return arr;

	}

	public static void display(int[][] arr) {

		for (int row = 0; row < arr.length; row++) {

			for (int col = 0; col < arr[row].length; col++) {
				System.out.print(arr[row][col] + " ");
			}

			System.out.println();
		}

		// for (int[] valr : arr) {
		//
		// for (int valc : valr) {
		// System.out.print(valc + " ");
		// }
		//
		// System.out.println();
		// }

	}

	public static void verticalDisplay(int[][] arr) {

		for (int col = 0; col < arr[0].length; col++) {

			for (int row = 0; row < arr.length; row++) {
				System.out.print(arr[row][col] + " ");
			}
		}

	}

	public static void waveDisplay(int[][] arr) {

		for (int col = 0; col < arr[0].length; col++) {

			if (col % 2 == 0) {
				for (int row = 0; row < arr.length; row++) {
					System.out.print(arr[row][col] + " ");
				}
			} else {
				for (int row = arr.length - 1; row >= 0; row--) {
					System.out.print(arr[row][col] + " ");
				}
			}
		}

	}

	public static void spiralDisplay(int[][] arr) {

		int rowmin = 0;
		int rowmax = arr.length - 1;
		int colmin = 0;
		int colmax = arr[0].length - 1;
		int nel = arr.length * arr[0].length;
		int counter = 0;

		while (counter < nel) {
			// first col
			for (int row = rowmin; counter < nel && row <= rowmax; row++) {
				System.out.print(arr[row][colmin] + " ");
				counter++;
			}
			colmin++;

			// last row
			for (int col = colmin; counter < nel && col <= colmax; col++) {
				System.out.print(arr[rowmax][col] + " ");
				counter++;
			}
			rowmax--;

			// last col
			for (int row = rowmax; counter < nel && row >= rowmin; row--) {
				System.out.print(arr[row][colmax] + " ");
				counter++;
			}
			colmax--;

			// first row
			for (int col = colmax; counter < nel && col >= colmin; col--) {
				System.out.print(arr[rowmin][col] + " ");
				counter++;
			}
			rowmin++;
		}

	}

	public static int[][] matrixMultiplication(int[][] one, int[][] two) {

		int r1 = one.length;
		int c1 = one[0].length;
		int r2 = two.length;
		int c2 = two[0].length;
		int cd = c1;

		if (c1 != r2) {
			return null;
		}

		int[][] ans = new int[r1][c2];

		for (int row = 0; row < ans.length; row++) {

			for (int col = 0; col < ans[row].length; col++) {

				int sum = 0;
				for (int k = 0; k < cd; k++) {
					sum = sum + one[row][k] * two[k][col];
				}
				ans[row][col] = sum;
			}
		}

		return ans;

	}
}

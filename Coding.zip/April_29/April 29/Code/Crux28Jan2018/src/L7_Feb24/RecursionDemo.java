package L7_Feb24;

/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 * @date 24-Feb-2018
 */

public class RecursionDemo {

	public static void main(String[] args) {

		// PDIWithSkips(6);
		System.out.println(factorial(3));
		int[] arr = { 50, 40, 80, 90, 70, 10, 30, 60, 20 };
		// displayArray(arr, 0);
		// System.out.println(findFirstIndex(arr, 0, 9));
		// int[] val = findAllIndex(arr, 0, 9, 0);
		// for (int v : val) {
		// System.out.println(v);
		// }

		// printBox(1, 1, 5);

		// quickSort(arr, 0, arr.length - 1);

		for (int val : arr) {
			System.out.println(val);
		}
	}

	public static void PD(int n) {

		if (n == 0) {
			return;
		}

		// Self Work
		System.out.println(n);

		// SmallerInput
		PD(n - 1);
	}

	public static void PI(int n) {

		if (n == 0) {
			return;
		}

		PI(n - 1);

		System.out.println(n);
	}

	public static void PDI(int n) {

		if (n == 0) {
			return;
		}

		System.out.println(n);
		PDI(n - 1);
		System.out.println(n);
	}

	public static void PDIWithSkips(int n) {

		if (n == 0) {
			return;
		}

		if (n % 2 != 0)
			System.out.println(n);
		PDIWithSkips(n - 1);

		if (n % 2 == 0)
			System.out.println(n);
	}

	public static int factorial(int n) {

		if (n == 0) {
			return 1;
		}

		int fnm1 = factorial(n - 1);
		int fn = n * fnm1;

		return fn;

	}

	public static int power(int x, int n) {

		if (n == 0) {
			return 1;
		}

		int pnm1 = power(x, n - 1);
		int pn = x * pnm1;

		return pn;
	}

	public static int fibonacci(int n) {

		if (n == 0 || n == 1) {
			return n;
		}

		int fnm1 = fibonacci(n - 1);
		int fnm2 = fibonacci(n - 2);

		int fn = fnm1 + fnm2;

		return fn;
	}

	public static void displayArray(int[] arr, int vidx) {

		if (vidx == arr.length) {
			return;
		}

		System.out.println(arr[vidx]);
		displayArray(arr, vidx + 1);

	}

	public static void displayArrayReverse(int[] arr, int vidx) {

		if (vidx == arr.length) {
			return;
		}

		displayArray(arr, vidx + 1);
		System.out.println(arr[vidx]);
	}

	public static int maxOfArray(int[] arr, int vidx) {

		if (arr.length == vidx) {
			return Integer.MIN_VALUE;
		}

		int ra = maxOfArray(arr, vidx + 1);

		if (arr[vidx] > ra) {
			return arr[vidx];
		} else {
			return ra;
		}
	}

	public static boolean findBoolean(int[] arr, int vidx, int item) {

		if (vidx == arr.length) {
			return false;
		}

		if (arr[vidx] == item) {
			return true;
		}

		boolean ra = findBoolean(arr, vidx + 1, item);
		return ra;
	}

	public static int findFirstIndex(int[] arr, int vidx, int item) {

		if (vidx == arr.length) {
			return -1;
		}

		if (arr[vidx] == item) {
			return vidx;
		}

		int ra = findFirstIndex(arr, vidx + 1, item);
		return ra;
	}

	public static int findLastIndex(int[] arr, int vidx, int item) {

		if (vidx == arr.length) {
			return -1;
		}

		int ra = findLastIndex(arr, vidx + 1, item);

		if (ra == -1 && item == arr[vidx]) {
			return vidx;
		} else {
			return ra;
		}
	}

	public static int[] findAllIndex(int[] arr, int vidx, int item, int count) {

		if (vidx == arr.length) {
			int[] baseResult = new int[count];
			return baseResult;
		}

		if (arr[vidx] == item) {
			int[] ra = findAllIndex(arr, vidx + 1, item, count+1);
			ra[count] = vidx;
			return ra;
		} else {
			int[] ra = findAllIndex(arr, vidx + 1, item, count);
			return ra;
		}

	}

	public static void printRows(int row, int n) {

		if (row == n + 1) {
			return;
		}

		System.out.println("*");
		printRows(row + 1, n);
	}

	public static void printBox(int row, int col, int n) {

		if (row == n + 1) {
			return;
		}

		if (col > row) {

			printBox(row + 1, 1, n);
			System.out.println();
			return;
		}

		printBox(row, col + 1, n);
		System.out.print("*");
	}

	public static void BubbleSort(int[] arr, int si, int ei) {

		if (ei == 0) {
			return;
		}

		if (si == ei) {
			BubbleSort(arr, 0, ei - 1);
			return;
		}
		if (arr[si + 1] < arr[si]) {

			int temp = arr[si];
			arr[si] = arr[si + 1];
			arr[si + 1] = temp;
		}

		BubbleSort(arr, si + 1, ei);
	}

	public static int[] mergeTwoSortedArrays(int[] arr1, int[] arr2) {

		int[] rv = new int[arr1.length + arr2.length];

		int i = 0;
		int j = 0;
		int k = 0;

		while (i < arr1.length && j < arr2.length) {

			if (arr1[i] < arr2[j]) {
				rv[k] = arr1[i];
				i++;
				k++;
			} else {
				rv[k] = arr2[j];
				j++;
				k++;
			}
		}

		if (i == arr1.length) {
			while (j < arr2.length) {
				rv[k] = arr2[j];
				j++;
				k++;
			}
		}

		if (j == arr2.length) {
			while (i < arr1.length) {
				rv[k] = arr1[i];
				i++;
				k++;
			}
		}

		return rv;

	}

	public static int[] mergeSort(int[] arr, int lo, int hi) {

		if (lo == hi) {
			int[] br = new int[1];
			br[0] = arr[lo];
			return br;
		}

		int mid = (lo + hi) / 2;

		int[] fh = mergeSort(arr, lo, mid);
		int[] sh = mergeSort(arr, mid + 1, hi);

		int[] merged = mergeTwoSortedArrays(fh, sh);

		return merged;
	}

	public static void quickSort(int[] arr, int lo, int hi) {

		if (lo >= hi) {
			return;
		}
		int left = lo;
		int right = hi;
		int mid = (lo + hi) / 2;
		int pivot = arr[mid];

		while (left <= right) {

			while (arr[left] < pivot) {
				left++;
			}

			while (arr[right] > pivot) {
				right--;
			}

			if (left <= right) {
				int temp = arr[left];
				arr[left] = arr[right];
				arr[right] = temp;
				left++;
				right--;
			}
		}

		quickSort(arr, lo, right);
		quickSort(arr, left, hi);
	}

}

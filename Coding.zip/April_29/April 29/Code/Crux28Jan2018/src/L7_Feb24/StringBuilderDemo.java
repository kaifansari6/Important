package L7_Feb24;

import java.util.ArrayList;

/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 * @date 24-Feb-2018
 */

public class StringBuilderDemo {

	public static void main(String[] args) {

		String s = "hello";

		StringBuilder sb = new StringBuilder(s);
		System.out.println(sb);

		// System.out.println(sb.charAt(3));
		// sb.insert(2, 'd') ;
		// System.out.println(sb);
		// sb.insert(4, "abc") ;
		// System.out.println(sb);
		//
		// sb.append("xyz") ;
		// System.out.println(sb);

		sb.replace(2, 4, "defghi");
		System.out.println(sb);
		
		sb.deleteCharAt(2) ;
		System.out.println(sb);

		String str = sb.toString() ;
	}

}

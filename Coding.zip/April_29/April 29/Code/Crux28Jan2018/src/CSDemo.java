
/**
 * @author Garima Chhikara
 * @date Jan 28, 2018
 */

public class CSDemo {

	public static void main(String[] args) {

		int marks = 9;
		int pack = 5;

		if (marks > 70 || pack > 10) {

			System.out.println("Good");
		} else {
			System.out.println("Bad");
		}

	}

}

package Assignments;

import java.util.Scanner;

/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 * @date 23-Feb-2018
 */

public class Assign3 {

	static Scanner scn = new Scanner(System.in);

	public static void main(String[] args) {

		// System.out.println(Q18(6));
		// Q19();

		// char ch = 'x';
		// if (ch != 'x' && ch != 'X') {
		// System.out.println("hi");
		// }

	}

	public static boolean Q18(int n) {

		int prev = scn.nextInt();
		boolean gd = true;

		for (int i = 1; i <= n - 1; i++) {

			int curr = scn.nextInt();

			if (gd == true) {

				if (curr < prev) {
					//
				} else {
					gd = false;
				}

			} else {
				if (curr > prev) {
					//
				} else {
					return false;
				}
			}
			
			prev = curr ;

		}

		return true;

	}

	public static void Q19() {

		while (true) {

			char ch = scn.next().charAt(0);

			if (ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '%') {

				int num1 = scn.nextInt();
				int num2 = scn.nextInt();

				if (ch == '+') {
					System.out.println(num1 + num2);
				} else if (ch == '-') {
					System.out.println(num1 - num2);
				} else if (ch == '*') {
					System.out.println(num1 * num2);
				} else if (ch == '/') {
					System.out.println(num1 / num2);
				} else if (ch == '%') {
					System.out.println(num1 % num2);
				}

			} else if (ch == 'x' || ch == 'X') {
				break;
			} else {
				System.out.println("Invalid operation. Try again.");
			}

		}

	}

}

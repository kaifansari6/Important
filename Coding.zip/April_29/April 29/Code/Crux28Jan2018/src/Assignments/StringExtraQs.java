package Assignments;

/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 * @date 23-Feb-2018
 */

public class StringExtraQs {

	public static void main(String[] args) {

		System.out.println(reverse("300*70-6+30"));
	}

	public static String reverse(String str) {

		String subans = "";
		String ans = "";

		for (int i = str.length() - 1; i >= 0; i--) {

			char ch = str.charAt(i);

			if (ch == '+' || ch == '*' || ch == '/' || ch == '-' || ch == '%') {
				ans += subans;
				ans += ch;
				subans = "";
			} else {
				subans = ch + subans;
			}
		}

		ans += subans;

		return ans;

	}

}

package Assignments;

import java.util.Arrays;

/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 * @date 23-Feb-2018
 */

public class Assign4 {

	public static void main(String[] args) {

		int[] arr = { 3, 1, 9, 7, 5, -1 };
		Arrays.sort(arr);
		Arrays.fill(arr, 1);
		Q13IV(arr, 9);

		String s = "12345" ;
		int in = Integer.parseInt(s);
		System.out.println(in);

	}

	public static void Q13(int[] arr, int target) {

		for (int i = 0; i < arr.length; i++) {

			for (int j = i + 1; j < arr.length; j++) {

				for (int k = j + 1; k < arr.length; k++) {

					if (arr[i] + arr[j] + arr[k] == target) {
						System.out.println(arr[i] + ", " + arr[j] + " and " + arr[k]);
					}

				}
			}
		}

	}

	public static void Q13IV(int[] arr, int target) {

		for (int i = 0; i < arr.length; i++) {

			int sumToCal = target - arr[i];

			int j = i + 1;
			int k = arr.length - 1;

			while (j < k) {

				if (arr[j] + arr[k] > sumToCal) {
					k--;
				} else if (arr[j] + arr[k] < sumToCal) {
					j++;
				} else {
					System.out.println(arr[i] + ", " + arr[j] + " and " + arr[k]);
					j++;
					k--;
				}

			}
		}

	}

}

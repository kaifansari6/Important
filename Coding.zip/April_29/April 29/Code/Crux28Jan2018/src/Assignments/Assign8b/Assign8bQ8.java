package Assignments.Assign8b;

import java.util.Arrays;

/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 * @date 30-Mar-2018
 */

public class Assign8bQ8 {

	public static void main(String[] args) {

		int n = 11;
		boolean[] primes = SOE(n);

		int[] sl = makeSnakenLaddersBoard(primes);

		int[] input = { 5, 2, 6, 2 };
		boolean val = q8(0, n, input, 0, sl);

		System.out.println(val);
	}

	public static boolean q8(int curr, int end, int[] input, int vidx, int[] sl) {

		if (curr == end) {
			return true;
		}
		if (vidx == input.length) {
			return false;
		}
		if (curr > end) {
			return false;
		}

		if (sl[curr] != 0) {
			return q8(sl[curr], end, input, vidx, sl);
		} else {
			return q8(curr + input[vidx], end, input, vidx + 1, sl);
		}
	}

	public static int[] makeSnakenLaddersBoard(boolean[] primes) {

		int[] snakesladders = new int[primes.length];

		int count = 0;
		int left = 0;
		int right = primes.length - 1;

		while (left < right) {

			while (primes[left] == false) {
				left++;
			}

			while (primes[right] == false) {
				right--;
			}

			if (left < right) {
				if (count % 2 == 0)
					snakesladders[left] = right;
				else
					snakesladders[right] = left;

				left++;
				right--;
				count++;
			}

		}

		return snakesladders;
	}

	public static boolean[] SOE(int n) {

		boolean[] primes = new boolean[n + 1];
		Arrays.fill(primes, true);

		primes[0] = false;
		primes[1] = false;

		for (int table = 2; table * table <= n; table++) {

			if (primes[table] == false) {
				continue;
			}

			for (int multiplier = 2; table * multiplier <= n; multiplier++) {

				primes[table * multiplier] = false;
			}

		}

		return primes;

	}

}

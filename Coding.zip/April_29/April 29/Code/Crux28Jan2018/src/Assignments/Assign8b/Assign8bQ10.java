package Assignments.Assign8b;

import java.util.Arrays;
import java.util.Scanner;

/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 * @date 30-Mar-2018
 */

public class Assign8bQ10 {

	public static void main(String[] args) {

		Scanner scn = new Scanner(System.in);
		int n = scn.nextInt();
		boolean[] primes = SOE(n * n);
		int[] mp = makeminesports(primes);
		System.out.println(q10Count(0, 0, n - 1, n - 1, mp));
		q10(0, 0, n - 1, n - 1, "{0-0}", mp);
	}

	public static int[] makeminesports(boolean[] primes) {

		int[] minesports = new int[primes.length];

		int count = 0;
		for (int i = 0; i < primes.length; i++) {

			if (primes[i] == false) {
				minesports[i] = 2;
			} else {
				if (count % 2 == 0) {
					minesports[i] = 0;
				} else {
					minesports[i] = 1;
				}

				count++;
			}
		}

		return minesports;
	}

	public static boolean[] SOE(int n) {

		boolean[] primes = new boolean[n + 1];
		Arrays.fill(primes, true);

		primes[0] = false;
		primes[1] = false;

		for (int table = 2; table * table <= n; table++) {

			if (primes[table] == false) {
				continue;
			}

			for (int multiplier = 2; table * multiplier <= n; multiplier++) {

				primes[table * multiplier] = false;
			}

		}

		return primes;

	}

	public static void q10(int cr, int cc, int er, int ec, String asf, int[] mp) {

		if (cr == er && cc == ec) {
			System.out.print(asf + " ");
			return;
		}

		if (cr > er || cc > ec) {
			return;
		}

		int val = (cr * (ec + 1)) + (cc + 1);
		if (mp[val] == 0) {
			return;
		} else if (mp[val] == 1) {
			q10(er, ec, er, ec, asf + "P{" + er + "-" + ec + "}", mp);
		}

		// knight
		q10(cr + 2, cc + 1, er, ec, asf + "K{" + (cr + 2) + "-" + (cc + 1) + "}", mp);
		q10(cr + 1, cc + 2, er, ec, asf + "K{" + (cr + 1) + "-" + (cc + 2) + "}", mp);

		// rook
		if (cr == 0 || cr == er || cc == 0 || cc == ec) {
			for (int move = 1; move <= ec; move++) {
				q10(cr, cc + move, er, ec, asf + "R{" + cr + "-" + (cc + move) + "}", mp);
			}

			for (int move = 1; move <= ec; move++) {
				q10(cr + move, cc, er, ec, asf + "R{" + (cr + move) + "-" + cc + "}", mp);
			}
		}

		// bishop
		if (cr == cc || cr + cc == ec) {
			for (int move = 1; move <= ec; move++) {
				q10(cr + move, cc + move, er, ec, asf + "B{" + (cr + move) + "-" + (cc + move) + "}", mp);
			}
		}
	}

	public static int q10Count(int cr, int cc, int er, int ec, int[] mp) {

		if (cr == er && cc == ec) {
			return 1;
		}

		if (cr > er || cc > ec) {
			return 0;
		}

		int count = 0;

		int val = (cr * (ec + 1)) + (cc + 1);
		if (mp[val] == 0) {
			return 0;
		} else if (mp[val] == 1) {
			count += q10Count(er, ec, er, ec, mp);
		}

		// knight
		count += q10Count(cr + 2, cc + 1, er, ec, mp);
		count += q10Count(cr + 1, cc + 2, er, ec, mp);

		// rook
		if (cr == 0 || cr == er || cc == 0 || cc == ec) {
			for (int move = 1; move <= ec; move++) {
				count += q10Count(cr, cc + move, er, ec, mp);
			}

			for (int move = 1; move <= ec; move++) {
				count += q10Count(cr + move, cc, er, ec, mp);
			}
		}

		// bishop
		if (cr == cc || cr + cc == ec) {
			for (int move = 1; move <= ec; move++) {
				count += q10Count(cr + move, cc + move, er, ec, mp);
			}
		}

		return count;
	}

}

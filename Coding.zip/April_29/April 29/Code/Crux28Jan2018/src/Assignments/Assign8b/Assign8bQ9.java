package Assignments.Assign8b;

import java.util.Arrays;
import java.util.Scanner;

/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 * @date 30-Mar-2018
 */

public class Assign8bQ9 {

	public static void main(String[] args) {

		Scanner scn = new Scanner(System.in);
		int n = scn.nextInt();
		System.out.println(q9C(0, 0, n - 1, n - 1));
		q9(0, 0, n - 1, n - 1, "{0-0}");
	}

	public static void q9(int cr, int cc, int er, int ec, String asf) {

		if (cr == er && cc == ec) {
			System.out.print(asf + " ");
			return;
		}

		if (cr > er || cc > ec) {
			return;
		}

		// knight
		q9(cr + 2, cc + 1, er, ec, asf + "K{" + (cr + 2) + "-" + (cc + 1) + "}");
		q9(cr + 1, cc + 2, er, ec, asf + "K{" + (cr + 1) + "-" + (cc + 2) + "}");

		// rook
		if (cr == 0 || cr == er || cc == 0 || cc == ec) {
			for (int move = 1; move <= ec; move++) {
				q9(cr, cc + move, er, ec, asf + "R{" + cr + "-" + (cc + move) + "}");

			}

			for (int move = 1; move <= ec; move++) {
				q9(cr + move, cc, er, ec, asf + "R{" + (cr + move) + "-" + cc + "}");
			}
		}

		// bishop
		if (cr == cc || cr + cc == ec) {
			for (int move = 1; move <= ec; move++) {
				q9(cr + move, cc + move, er, ec, asf + "B{" + (cr + move) + "-" + (cc + move) + "}");
			}
		}
	}

	public static int q9C(int cr, int cc, int er, int ec) {

		if (cr == er && cc == ec) {
			return 1;
		}

		if (cr > er || cc > ec) {
			return 0;
		}

		int count = 0;

		// knight
		count += q9C(cr + 2, cc + 1, er, ec);
		count += q9C(cr + 1, cc + 2, er, ec);

		// rook
		if (cr == 0 || cr == er || cc == 0 || cc == ec) {
			for (int move = 1; move <= ec; move++) {
				count += q9C(cr, cc + move, er, ec);

			}

			for (int move = 1; move <= ec; move++) {
				count += q9C(cr + move, cc, er, ec);
			}
		}

		// bishop
		if (cr == cc || cr + cc == ec) {
			for (int move = 1; move <= ec; move++) {
				count += q9C(cr + move, cc + move, er, ec);
			}
		}

		return count;
	}

	public static boolean[] SOE(int n) {

		boolean[] primes = new boolean[n + 1];
		Arrays.fill(primes, true);

		primes[0] = false;
		primes[1] = false;

		for (int table = 2; table * table <= n; table++) {

			if (primes[table] == false) {
				continue;
			}

			for (int multiplier = 2; table * multiplier <= n; multiplier++) {

				primes[table * multiplier] = false;
			}

		}

		return primes;

	}

}

package Assignments.Assign8b;

import java.util.Arrays;

/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 * @date 21-Mar-2018
 */

public class Assign8bQ7 {

	public static void main(String[] args) {

		int n = 12;

		boolean[] primes = SOE(n);

		int[] ladders = makeLadders(primes);

		// for (int val : ladders) {
		// System.out.println(val);
		// }

		ladderBoard(0, n, ladders, "");
	}

	public static void ladderBoard(int curr, int end, int[] ladders, String asf) {

		if (curr == end) {
			System.out.println(asf);
			return;
		}

		if (curr > end) {
			return;
		}

		if (ladders[curr] != 0) {
			ladderBoard(ladders[curr], end, ladders, asf + "L{" + curr + "," + ladders[curr] + "}");
		} else {
			for (int dice = 1; dice <= 6; dice++) {
				ladderBoard(curr + dice, end, ladders, asf + dice);
			}
		}
	}

	public static int[] makeLadders(boolean[] primes) {

		int[] ladders = new int[primes.length];

		int left = 0;
		int right = primes.length - 1;

		while (left < right) {

			while (primes[left] == false) {
				left++;
			}

			while (primes[right] == false) {
				right--;
			}

			if (left < right) {
				ladders[left] = right;
				left++;
				right--;
			}

		}

		return ladders;

	}

	public static boolean[] SOE(int n) {

		boolean[] primes = new boolean[n + 1];
		Arrays.fill(primes, true);

		primes[0] = false;
		primes[1] = false;

		for (int table = 2; table * table <= n; table++) {

			if (primes[table] == false) {
				continue;
			}

			for (int multiplier = 2; table * multiplier <= n; multiplier++) {

				primes[table * multiplier] = false;
			}

		}

		return primes;

	}

}

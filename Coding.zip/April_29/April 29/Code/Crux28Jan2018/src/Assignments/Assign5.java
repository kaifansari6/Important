package Assignments;

/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 * @date 23-Feb-2018
 */

public class Assign5 {

	public static void main(String[] args) {
		
		System.out.println(Q7("aaabbccddsaa"));

	}

	public static String Q8(String str) {

		int count = 1;
		String ans = "";
		for (int i = 0; i < str.length() - 1; i++) {

			if (str.charAt(i) == str.charAt(i + 1)) {
				count++;
			} else {
				ans += str.charAt(i);
				if (count != 1)
					ans += count;
				count = 1;
			}
		}

		ans += str.charAt(str.length() - 1);
		if (count != 1)
			ans += count;
		
		return ans ;
	}
	
	public static String Q7(String str) {

		String ans = "";
		for (int i = 0; i < str.length() - 1; i++) {

			if (str.charAt(i) == str.charAt(i + 1)) {
				
			} else {
				ans += str.charAt(i);				
			}
		}

		ans += str.charAt(str.length() - 1);
		
		return ans ;
	}

}

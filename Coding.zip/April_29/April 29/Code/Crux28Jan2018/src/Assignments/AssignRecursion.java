package Assignments;

import java.util.ArrayList;

/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 */

public class AssignRecursion {

	public static void main(String[] args) {
		// System.out.println(codesOfStringAL("1125"));
		// System.out.println(removeDuplicates("hellllobyeeeh"));
		// System.out.println(replaceHi("hihihibyeeeehihiih"));

		int[] arr = { 50, 40, 30, 20, 10 };
		// SelectionSort(arr, 0, arr.length - 1);

		for (int val : arr) {
			System.out.println(val);
		}

		String str = "abbab";
		if (str.charAt(0) == 'a') {
			System.out.println(obediantString(str));
		} else {
			System.out.println("false");
		}

		ArrayList<String> list = new ArrayList<>();
		list.add("dg");
		list.add("dh");
		list.add("di");

		for (String rrs : list) {
			System.out.println(rrs);
		}

		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
		}
	}

	public static void codesOfString(String str, String ans) {

		if (str.length() == 0) {
			System.out.println(ans);
			return;
		}

		String s1 = str.substring(0, 1);
		int i1 = Integer.parseInt(s1);
		int atba1 = i1 + 'a' - 1;

		codesOfString(str.substring(1), ans + ((char) atba1));

		if (str.length() >= 2) {
			String s2 = str.substring(0, 2);
			int i2 = Integer.parseInt(s2);
			int atba2 = i2 + 'a' - 1;
			if (i2 <= 26)
				codesOfString(str.substring(2), ans + ((char) atba2));
		}

	}

	public static ArrayList<String> codesOfStringAL(String str) {

		if (str.length() == 0) {
			ArrayList<String> br = new ArrayList<>();
			br.add("");
			return br;
		}

		ArrayList<String> mr = new ArrayList<>();

		String s1 = str.substring(0, 1);
		int i1 = Integer.parseInt(s1);
		int atba1 = i1 + 'a' - 1;

		ArrayList<String> rr1 = codesOfStringAL(str.substring(1));

		for (String rr1s : rr1) {
			mr.add((char) atba1 + rr1s);
		}

		if (str.length() >= 2) {
			String s2 = str.substring(0, 2);
			int i2 = Integer.parseInt(s2);
			int atba2 = i2 + 'a' - 1;
			if (i2 <= 26) {
				ArrayList<String> rr2 = codesOfStringAL(str.substring(2));
				for (String rr2s : rr2) {
					mr.add((char) atba2 + rr2s);
				}
			}
		}

		return mr;

	}

	public static String removeDuplicates(String str) {

		if (str.length() == 1) {
			return str;
		}

		if (str.charAt(0) == str.charAt(1)) {
			return removeDuplicates(str.substring(1));

		} else {
			return str.charAt(0) + removeDuplicates(str.substring(1));
		}

	}

	public static int countHi(String str) {

		if (str.length() == 1 || str.length() == 0) {
			return 0;
		}

		String tc = str.substring(0, 2);

		if (tc.equals("hi")) {
			return countHi(str.substring(2)) + 1;
		} else {
			return countHi(str.substring(1));
		}

	}

	public static String removeHi(String str) {

		if (str.length() == 1 || str.length() == 0) {
			return str;
		}

		String tc = str.substring(0, 2);

		if (tc.equals("hi")) {
			return removeHi(str.substring(2));
		} else {
			return str.charAt(0) + removeHi(str.substring(1));
		}

	}

	public static String replaceHi(String str) {

		if (str.length() == 1 || str.length() == 0) {
			return str;
		}

		String tc = str.substring(0, 2);

		if (tc.equals("hi")) {
			return "bye" + replaceHi(str.substring(2));
		} else {
			return str.charAt(0) + replaceHi(str.substring(1));
		}

	}

	public static int findMinIndex(int[] arr, int lo, int hi) {

		if (lo == hi) {
			return lo;
		}
		int rr = findMinIndex(arr, lo + 1, hi);

		if (arr[lo] < arr[rr]) {
			return lo;
		} else {
			return rr;
		}
	}

	public static void SelectionSort(int[] arr, int si, int ei) {

		if (si == ei)
			return;

		int minIdx = findMinIndex(arr, si, ei);

		// self work
		int temp = arr[si];
		arr[si] = arr[minIdx];
		arr[minIdx] = temp;

		SelectionSort(arr, si + 1, ei);
	}

	public static boolean obediantString(String str) {

		char ch = str.charAt(0);

		if (str.length() >= 1 && ch == 'a') {

			if (str.length() == 1) {
				return true;
			} else if (str.length() >= 2 && str.charAt(1) == 'a') {
				return obediantString(str.substring(1));
			} else if (str.length() >= 3 && str.substring(1, 3).equals("bb")) {
				return obediantString(str.substring(1));
			}
		}

		else if (str.length() >= 2 && str.substring(0, 2).equals("bb")) {

			if (str.length() == 2) {
				return true;
			} else if (str.length() >= 3 && str.charAt(2) == 'a') {
				return obediantString(str.substring(2));
			}
		}

		return false;

	}

}

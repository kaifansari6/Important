package Assignments;

/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 */

public class Assign6 {

	public static void main(String[] args) {

		Q4(0, 0, 5, 1);
	}

	public static void Q4(int row, int col, int n, int val) {

		if (row == n) {
			return;
		}

		if (col > row) {
			System.out.println();
			Q4(row + 1, 0, n, 1);
			return;
		}

		System.out.print(val + "\t");
		val = (val * (row - col)) / (col + 1);
		Q4(row, col + 1, n, val);

	}

}

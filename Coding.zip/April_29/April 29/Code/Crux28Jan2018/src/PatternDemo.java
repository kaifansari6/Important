
/**
 * @author Garima Chhikara
 * @date Jan 28, 2018
 */

public class PatternDemo {

	public static void main(String[] args) {

		int n = 5;

		int row = 1;
		while (row <= n) {

			// row work
			int col = 1;
			while (col <= n) {

				if (row == 1 || row == n || col == 1 || col == n)
					System.out.print("*");
				else
					System.out.print(" ");
				
				col = col + 1;
			}

			// next row work
			System.out.println();
			row = row + 1;
		}

	}

}
